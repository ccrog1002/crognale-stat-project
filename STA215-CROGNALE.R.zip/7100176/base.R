
## Project:  Base class script for STA 215, spring 2022
# Located:   Kline Posit Cloud
# File Name: Kline(2023_2_27)STA215_base
# Date:      2023_2_27
# Who:       Zachary D. Kline

### Settings + Packages
# Install packages 
install.packages('readr')
install.packages("dplyr")
install.packages("tidytext")
install.packages("tidyverse")
install.packages('ggplot2')
install.packages("haven")
install.packages("psych")
install.packages("readxl")


